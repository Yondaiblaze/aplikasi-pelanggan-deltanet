<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi OTP - DeltaNet</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background-color: #f5f5f5; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
        .otp-container { background-color: #e0e0e0; padding: 40px; border-radius: 10px; width: 400px; text-align: center; }
        .logo { margin-bottom: 30px; display: flex; align-items: center; justify-content: center; gap: 10px; }
        .logo img { height: 40px; width: auto; }
        .logo h1 { color: #1e3a8a; font-size: 24px; font-weight: bold; }
        .otp-info { margin-bottom: 30px; color: #666; }
        .otp-info h2 { color: #333; margin-bottom: 10px; }
        .otp-inputs { display: flex; justify-content: center; gap: 10px; margin-bottom: 30px; }
        .otp-input { width: 45px; height: 50px; text-align: center; font-size: 20px; border: 2px solid #ddd; border-radius: 8px; background: white; }
        .otp-input:focus { border-color: #3b82f6; outline: none; }
        .verify-btn { width: 100%; padding: 12px; background-color: #3b82f6; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; margin-bottom: 20px; }
        .verify-btn:hover { background-color: #2563eb; }
        .resend-section { color: #666; font-size: 14px; }
        .resend-btn { color: #3b82f6; text-decoration: none; cursor: pointer; }
        .timer { color: #f59e0b; font-weight: bold; }
        .error-message { background-color: #fee2e2; color: #dc2626; padding: 10px; border-radius: 5px; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="otp-container">
        <div class="logo">
            <img src="<?php echo e(asset('deltanet-logo.png')); ?>" alt="DeltaNet Logo">
            <h1>Delta<span>Net</span></h1>
        </div>

        <div class="otp-info">
            <h2>Verifikasi OTP</h2>
            <p>Kode OTP telah dikirim ke nomor</p>
            
            <p><strong><?php echo e(session('otp_phone') ?? 'Nomor tidak terdeteksi'); ?></strong></p>
        </div>

        <?php if($errors->any()): ?>
            <div class="error-message">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div><?php echo e($error); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('otp.verify')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="otp-inputs">
                
                <input type="text" class="otp-input" maxlength="1" name="otp[]" required autofocus>
                <input type="text" class="otp-input" maxlength="1" name="otp[]" required>
                <input type="text" class="otp-input" maxlength="1" name="otp[]" required>
                <input type="text" class="otp-input" maxlength="1" name="otp[]" required>
                <input type="text" class="otp-input" maxlength="1" name="otp[]" required>
                <input type="text" class="otp-input" maxlength="1" name="otp[]" required>
            </div>

            <button type="submit" class="verify-btn">Verifikasi OTP</button>
        </form>

        <div class="resend-section">
            <p id="timer-text">Tidak menerima kode? <span class="timer" id="timer">60</span>s</p>
            <a href="#" class="resend-btn" id="resend-btn" style="display: none;">Kirim Ulang OTP</a>
        </div>

        <div style="margin-top: 20px;">
            <a href="<?php echo e(route('login')); ?>" style="color: #666; text-decoration: none; font-size: 14px;">← Kembali ke Login</a>
        </div>
    </div>

    <script>
        const otpInputs = document.querySelectorAll('.otp-input');

        otpInputs.forEach((input, index) => {
            // Auto focus next
            input.addEventListener('input', function() {
                if (this.value.length === 1 && index < otpInputs.length - 1) {
                    otpInputs[index + 1].focus();
                }
            });

            // Handle backspace
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Backspace' && this.value === '' && index > 0) {
                    otpInputs[index - 1].focus();
                }
            });

            // Pastikan hanya angka
            input.addEventListener('keypress', function(e) {
                if (!/[0-9]/.test(e.key)) {
                    e.preventDefault();
                }
            });
        });

        // Timer Logic
        let timeLeft = 60;
        const timerSpan = document.getElementById('timer');
        const timerText = document.getElementById('timer-text');
        const resendBtn = document.getElementById('resend-btn');

        const countdown = setInterval(() => {
            timeLeft--;
            timerSpan.textContent = timeLeft;

            if (timeLeft <= 0) {
                clearInterval(countdown);
                timerText.style.display = 'none';
                resendBtn.style.display = 'inline';
            }
        }, 1000);
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\aplikasi-pelanggan-deltanet\frontend_web\resources\views/auth/otp.blade.php ENDPATH**/ ?>