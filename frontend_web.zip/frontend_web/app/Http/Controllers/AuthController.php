<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class AuthController extends Controller
{
    /* =======================
       HELPER: BIAR FORMAT HP SAMA SEMUA
    ======================= */
    private function formatPhone($countryCode, $phone)
    {
        $cleanPhone = ltrim($phone, '0');
        $fullPhone = $countryCode . $cleanPhone;
        return str_starts_with($fullPhone, '+') ? $fullPhone : '+' . $fullPhone;
    }

    /* =======================
       LOGIN (GERBANG 1: PASSWORD)
    ======================= */
    public function showLogin()
    {
        return view('auth.login');
    }

    public function login(Request $request)
    {
        $fullPhone = $this->formatPhone($request->country_code, $request->phone);

        $response = Http::post('http://127.0.0.1:8000/api/login', [
            'contact'  => $fullPhone,
            'password' => $request->password,
        ]);

        if ($response->successful()) {
            session([
                'otp_phone'   => $fullPhone,
                'remember_me' => $request->has('remember')
            ]);

            // LEMPAR KE GERBANG 2 (OTP)
            return redirect()->route('otp.verify')->with('success', 'Password benar! Masukkan kode OTP.');
        }

        return back()->withErrors(['error' => 'Nomor HP atau Password salah.']);
    }

    /* =======================
       REGISTER (ALUR: LANGSUNG DASHBOARD)
    ======================= */
    public function showRegister()
    {
        return view('auth.register');
    }

    public function register(Request $request)
    {
        $fullPhone = $this->formatPhone($request->country_code, $request->phone);

        $response = Http::post('http://127.0.0.1:8000/api/register', [
            'name'          => $request->name,
            'contact'       => $fullPhone,
            'password'      => $request->password,
            'referred_by'   => $request->referred_by,
        ]);

        if ($response->successful()) {
            $data = $response->json();

            // KARENA REGIS LANGSUNG DASHBOARD:
            // Simpan token & data user ke session
            session([
                'user_token' => $data['token'],
                'user_data'  => $data['user']
            ]);

            return redirect()->route('dashboard')->with('success', 'Registrasi berhasil! Selamat datang.');
        }

        return back()->withErrors(['error' => 'Gagal daftar: ' . ($response->json()['message'] ?? 'Terjadi kesalahan')]);
        }

    /* =======================
       LOGOUT
    ======================= */
    public function logout()
    {
        session()->flush();
        return redirect()->route('login')->with('success', 'Anda telah keluar. Sampai jumpa!');
    }
}
